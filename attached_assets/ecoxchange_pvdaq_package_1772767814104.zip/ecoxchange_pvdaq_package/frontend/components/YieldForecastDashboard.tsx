import React, { useEffect, useState } from 'react';

type MonthlyRow = {
  month: string;
  monthly_energy_kwh: number;
};

type ForecastRow = {
  forecast_month: string;
  forecast_energy_kwh: number;
  forecast_revenue_usd: number;
};

type Kpis = {
  total_mwh: number;
  avg_daily_mwh: number;
  start_ts: string;
  end_ts: string;
};

export default function YieldForecastDashboard() {
  const [monthly, setMonthly] = useState<MonthlyRow[]>([]);
  const [forecast, setForecast] = useState<ForecastRow[]>([]);
  const [kpis, setKpis] = useState<Kpis | null>(null);
  const [ppa, setPpa] = useState(0.085);

  useEffect(() => {
    async function load() {
      const [monthlyRes, forecastRes, kpiRes] = await Promise.all([
        fetch('/api/pvdaq/systems/9068/monthly'),
        fetch(`/api/pvdaq/systems/9068/forecast?ppa=${ppa}`),
        fetch('/api/pvdaq/systems/9068/kpis'),
      ]);
      setMonthly(await monthlyRes.json());
      setForecast(await forecastRes.json());
      setKpis(await kpiRes.json());
    }
    load();
  }, [ppa]);

  const trailing12Revenue = forecast.reduce((sum, row) => sum + row.forecast_revenue_usd, 0);

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
        <KpiCard label="Total Historical MWh" value={kpis ? Number(kpis.total_mwh).toFixed(0) : '...'} />
        <KpiCard label="Avg Daily MWh" value={kpis ? Number(kpis.avg_daily_mwh).toFixed(2) : '...'} />
        <KpiCard label="Forecast 12M Revenue" value={`$${trailing12Revenue.toFixed(0)}`} />
        <KpiCard label="Assumed PPA" value={`$${ppa.toFixed(3)}/kWh`} />
      </div>

      <div className="rounded-lg border p-4">
        <label className="mb-2 block text-sm font-medium">Assumed PPA ($/kWh)</label>
        <input
          type="number"
          step="0.001"
          value={ppa}
          onChange={(e) => setPpa(Number(e.target.value))}
          className="w-40 rounded border px-3 py-2"
        />
      </div>

      <div className="rounded-lg border p-4">
        <h3 className="mb-4 text-lg font-semibold">Monthly Generation (historical)</h3>
        <pre className="overflow-auto text-xs">{JSON.stringify(monthly.slice(-12), null, 2)}</pre>
      </div>

      <div className="rounded-lg border p-4">
        <h3 className="mb-4 text-lg font-semibold">12-Month Yield Forecast</h3>
        <pre className="overflow-auto text-xs">{JSON.stringify(forecast, null, 2)}</pre>
      </div>
    </div>
  );
}

function KpiCard({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg border p-4">
      <div className="text-sm text-gray-500">{label}</div>
      <div className="mt-2 text-2xl font-semibold">{value}</div>
    </div>
  );
}
