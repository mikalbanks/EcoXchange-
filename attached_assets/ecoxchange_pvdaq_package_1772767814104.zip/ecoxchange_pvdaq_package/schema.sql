CREATE TABLE IF NOT EXISTS pv_systems (
  system_id INTEGER PRIMARY KEY,
  public_name TEXT NOT NULL,
  source TEXT NOT NULL DEFAULT 'PVDAQ',
  capacity_kw NUMERIC,
  tracking_type TEXT,
  technology TEXT,
  location_state TEXT,
  latitude DOUBLE PRECISION,
  longitude DOUBLE PRECISION,
  timezone TEXT DEFAULT 'UTC',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS pv_telemetry_5m (
  system_id INTEGER NOT NULL REFERENCES pv_systems(system_id),
  ts TIMESTAMPTZ NOT NULL,
  ac_power_kw DOUBLE PRECISION,
  energy_kwh_interval DOUBLE PRECISION,
  interval_minutes DOUBLE PRECISION,
  quality_flag TEXT,
  PRIMARY KEY (system_id, ts)
);

SELECT create_hypertable('pv_telemetry_5m', 'ts', if_not_exists => TRUE);

CREATE INDEX IF NOT EXISTS idx_pv_telemetry_system_ts ON pv_telemetry_5m(system_id, ts DESC);

CREATE MATERIALIZED VIEW IF NOT EXISTS pv_daily_metrics AS
SELECT
  system_id,
  time_bucket('1 day', ts) AS day,
  SUM(energy_kwh_interval) AS daily_energy_kwh,
  AVG(ac_power_kw) AS avg_power_kw,
  MAX(ac_power_kw) AS peak_power_kw,
  COUNT(*) AS sample_count
FROM pv_telemetry_5m
GROUP BY system_id, day;

CREATE MATERIALIZED VIEW IF NOT EXISTS pv_monthly_metrics AS
SELECT
  system_id,
  time_bucket('1 month', ts) AS month,
  SUM(energy_kwh_interval) AS monthly_energy_kwh,
  AVG(ac_power_kw) AS avg_power_kw,
  MAX(ac_power_kw) AS peak_power_kw,
  COUNT(*) AS sample_count
FROM pv_telemetry_5m
GROUP BY system_id, month;

CREATE TABLE IF NOT EXISTS project_financial_assumptions (
  system_id INTEGER PRIMARY KEY REFERENCES pv_systems(system_id),
  assumed_ppa_usd_per_kwh NUMERIC NOT NULL DEFAULT 0.085,
  degradation_rate_annual NUMERIC NOT NULL DEFAULT 0.005,
  o_and_m_usd_per_kw_year NUMERIC,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
