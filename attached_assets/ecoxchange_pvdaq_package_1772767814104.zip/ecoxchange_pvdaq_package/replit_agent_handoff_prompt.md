# Replit Agent Handoff Prompt

You are implementing a real-data EcoXchange demo feature.

## Goal
Build a backend + frontend feature that ingests one public PVDAQ telemetry dataset into TimescaleDB and renders a yield forecast dashboard.

## Dataset
Use the included files for **PVDAQ system 9068**.
- `pvdaq_9068_cleaned_5min.csv`
- `pvdaq_9068_daily.csv`
- `pvdaq_9068_monthly.csv`
- `pvdaq_9068_forecast_12mo.csv`

## What to implement

### Database
1. Create the schema in `schema.sql`.
2. Ensure `pv_telemetry_5m` is a Timescale hypertable.
3. Add `pv_systems` metadata row for system 9068.

### ETL
1. Use `etl/load_pvdaq_9068.py` as the reference loader.
2. Make the loader idempotent if possible.
3. Refresh materialized views after ingestion.

### Backend API
Implement routes equivalent to:
- `GET /api/pvdaq/systems/:systemId/monthly`
- `GET /api/pvdaq/systems/:systemId/kpis`
- `GET /api/pvdaq/systems/:systemId/forecast?ppa=0.085&degradation=0.005`

### Frontend
Create a dashboard view that shows:
- KPI cards
- monthly generation chart
- monthly revenue chart
- 12-month forecast table/chart
- editable PPA assumption input

## Engineering constraints
- Use TypeScript where possible.
- Keep forecasting logic modular.
- Do not over-engineer model v1; seasonal historical averaging is acceptable.
- Make it easy to swap in a real SCADA feed later.

## Notes
This feature is intended to prove:
**telemetry -> financial modeling -> investor-facing yield intelligence**

Do not build token issuance or investment flows in this task.

## Success output
Return:
1. files changed
2. how to run locally / in Replit
3. any blockers or data assumptions
