"""Load cleaned PVDAQ telemetry into PostgreSQL / TimescaleDB.

Usage:
  DATABASE_URL=postgresql://... python etl/load_pvdaq_9068.py
"""
from __future__ import annotations
import os
from pathlib import Path
import pandas as pd
from sqlalchemy import create_engine, text

BASE = Path(__file__).resolve().parents[1]
CSV_PATH = BASE / 'pvdaq_9068_cleaned_5min.csv'
SYSTEM_ID = 9068

SYSTEM_METADATA = {
    'system_id': SYSTEM_ID,
    'public_name': 'PVDAQ 9068',
    'source': 'PVDAQ',
    'capacity_kw': 4700,
    'tracking_type': 'single-axis',
    'technology': 'CdTe',
    'location_state': 'CO',
    'latitude': None,
    'longitude': None,
}


def main() -> None:
    db_url = os.environ['DATABASE_URL']
    engine = create_engine(db_url)

    df = pd.read_csv(CSV_PATH, parse_dates=['timestamp'])
    df = df.rename(columns={'timestamp': 'ts'})

    with engine.begin() as conn:
        conn.execute(text(
            """
            INSERT INTO pv_systems(system_id, public_name, source, capacity_kw, tracking_type, technology, location_state, latitude, longitude)
            VALUES (:system_id, :public_name, :source, :capacity_kw, :tracking_type, :technology, :location_state, :latitude, :longitude)
            ON CONFLICT (system_id) DO UPDATE
            SET public_name = EXCLUDED.public_name,
                source = EXCLUDED.source,
                capacity_kw = EXCLUDED.capacity_kw,
                tracking_type = EXCLUDED.tracking_type,
                technology = EXCLUDED.technology,
                location_state = EXCLUDED.location_state;
            """
        ), SYSTEM_METADATA)

        df.to_sql('pv_telemetry_5m', conn, if_exists='append', index=False, method='multi', chunksize=5000)

        conn.execute(text(
            """
            INSERT INTO project_financial_assumptions(system_id, assumed_ppa_usd_per_kwh, degradation_rate_annual)
            VALUES (:system_id, 0.085, 0.005)
            ON CONFLICT (system_id) DO NOTHING;
            """
        ), {'system_id': SYSTEM_ID})

        conn.execute(text('REFRESH MATERIALIZED VIEW pv_daily_metrics;'))
        conn.execute(text('REFRESH MATERIALIZED VIEW pv_monthly_metrics;'))

    print(f'Loaded {len(df):,} telemetry rows for system {SYSTEM_ID}.')


if __name__ == '__main__':
    main()
