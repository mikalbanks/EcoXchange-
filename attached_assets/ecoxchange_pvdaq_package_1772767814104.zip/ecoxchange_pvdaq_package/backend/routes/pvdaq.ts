import type { Request, Response } from 'express';
import { Router } from 'express';
import { Pool } from 'pg';
import { buildSeasonalForecast } from '../lib/yieldForecast';

const router = Router();
const pool = new Pool({ connectionString: process.env.DATABASE_URL });

router.get('/systems/:systemId/monthly', async (req: Request, res: Response) => {
  const systemId = Number(req.params.systemId);
  const result = await pool.query(
    `SELECT to_char(month, 'YYYY-MM') AS month,
            monthly_energy_kwh,
            avg_power_kw,
            peak_power_kw,
            sample_count
       FROM pv_monthly_metrics
      WHERE system_id = $1
      ORDER BY month`,
    [systemId],
  );
  res.json(result.rows);
});

router.get('/systems/:systemId/kpis', async (req: Request, res: Response) => {
  const systemId = Number(req.params.systemId);
  const result = await pool.query(
    `SELECT COUNT(*) AS rows,
            MIN(ts) AS start_ts,
            MAX(ts) AS end_ts,
            SUM(energy_kwh_interval) / 1000.0 AS total_mwh,
            AVG(energy_kwh_interval) * 288 / 1000.0 AS avg_daily_mwh
       FROM pv_telemetry_5m
      WHERE system_id = $1`,
    [systemId],
  );
  res.json(result.rows[0]);
});

router.get('/systems/:systemId/forecast', async (req: Request, res: Response) => {
  const systemId = Number(req.params.systemId);
  const ppa = Number(req.query.ppa ?? 0.085);
  const degradation = Number(req.query.degradation ?? 0.005);
  const history = await pool.query(
    `SELECT to_char(month, 'YYYY-MM') AS month,
            monthly_energy_kwh
       FROM pv_monthly_metrics
      WHERE system_id = $1
      ORDER BY month`,
    [systemId],
  );
  const forecast = buildSeasonalForecast(history.rows, ppa, degradation, 12);
  res.json(forecast);
});

export default router;
