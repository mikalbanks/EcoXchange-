# Feature Spec: PVDAQ Telemetry Ingestion + Yield Forecast Dashboard

## Selected public dataset
- **Source:** NREL / DOE Open Energy Data Initiative PVDAQ public dataset
- **System ID:** 9068
- **System description:** 4.7 MW CdTe single-axis tracking system in Colorado
- **Raw file used:** `9068_ac_power_data.csv`

## Exact feature to build
Ingest one public PVDAQ telemetry dataset into TimescaleDB and expose a dashboard that shows:
1. raw and aggregated solar production
2. monthly generation trend
3. estimated PPA revenue
4. 12-month forward yield forecast

## Why this feature
This is the fastest path to proving the EcoXchange thesis that:

**energy telemetry -> financial modeling -> investor-facing yield intelligence**

It gives you a real data-backed demo before live SCADA integrations exist.

## Functional requirements

### Backend
- ingest cleaned 5-minute telemetry CSV into TimescaleDB
- store plant metadata in `pv_systems`
- aggregate daily and monthly generation
- calculate estimated revenue from an assumed PPA rate
- generate a simple 12-month forecast from seasonal historical averages
- expose API routes for charting and dashboard use

### Frontend
- chart monthly energy generation
- chart estimated monthly revenue
- show headline KPIs:
  - total historical MWh
  - average daily MWh
  - trailing 12-month revenue
  - next 12-month forecast revenue

### Forecast model v1
- simple seasonal monthly average model
- optional annual degradation assumption (default 0.5%)
- configurable assumed PPA price (default $0.085/kWh)

## Non-goals for v1
- live SCADA streaming
- investor transactions
- token issuance logic
- production-grade ML forecasting
- anomaly detection / predictive maintenance

## Success criteria
- data can be ingested locally or in Replit
- dashboard renders from real PVDAQ data
- finance metrics update when PPA assumption changes
- code is modular enough to add future systems

## Deliverables included
- raw CSV
- cleaned 5-minute CSV
- daily aggregation CSV
- monthly aggregation CSV
- 12-month forecast CSV
- TimescaleDB schema
- ETL loader script
- backend route examples
- frontend dashboard component stub
- Replit agent handoff prompt
