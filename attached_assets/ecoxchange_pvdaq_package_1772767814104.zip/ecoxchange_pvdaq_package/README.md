# EcoXchange PVDAQ Demo Package

This package gives you a real-data demo path for EcoXchange using one public PVDAQ system.

## Included data
- `pvdaq_9068_cleaned_5min.csv`
- `pvdaq_9068_daily.csv`
- `pvdaq_9068_monthly.csv`
- `pvdaq_9068_forecast_12mo.csv`

## Included implementation assets
- `schema.sql`
- `etl/load_pvdaq_9068.py`
- `backend/routes/pvdaq.ts`
- `backend/lib/yieldForecast.ts`
- `frontend/components/YieldForecastDashboard.tsx`
- `feature_spec.md`
- `replit_agent_handoff_prompt.md`

## Recommended first feature
Ingest one public PVDAQ system into TimescaleDB and show a yield forecast dashboard.

## Core demo narrative
Use this feature to show that EcoXchange can transform public or private energy telemetry into investor-facing yield analytics.
